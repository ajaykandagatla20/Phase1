using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LoginForm.Pages
{
    public class LoginFormModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
