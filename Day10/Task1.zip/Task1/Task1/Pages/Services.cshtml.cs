using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Task1.Pages
{
    public class ServicesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
