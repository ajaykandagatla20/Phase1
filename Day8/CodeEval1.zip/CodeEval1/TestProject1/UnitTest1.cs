using NUnit.Framework;
using CalculatorLibrary;

namespace CalculatorLibrary.Tests
{
    [TestFixture]
    public class CalculatorTests
    {
        private Calculator _calculator;

        [SetUp]
        public void Setup()
        {
            // Initialize the Calculator object before each test
            _calculator = new Calculator();
        }

        // Test for Addition
        [Test]
        public void Add_WhenCalled_ReturnsCorrectSum()
        {
            // Arrange
            double a = 10;
            double b = 20;

            // Act
            double result = _calculator.Add(a, b);

            // Assert
            Assert.AreEqual(30, result);
        }

        // Test for Subtraction
        [Test]
        public void Subtract_WhenCalled_ReturnsCorrectDifference()
        {
            // Arrange
            double a = 20;
            double b = 10;

            // Act
            double result = _calculator.Subtract(a, b);

            // Assert
            Assert.AreEqual(10, result);
        }

        // Test for Multiplication
        [Test]
        public void Multiply_WhenCalled_ReturnsCorrectProduct()
        {
            // Arrange
            double a = 10;
            double b = 20;

            // Act
            double result = _calculator.Multiply(a, b);

            // Assert
            Assert.AreEqual(200, result);
        }

        // Test for Division
        [Test]
        public void Divide_WhenCalledWithValidInputs_ReturnsCorrectQuotient()
        {
            // Arrange
            double a = 20;
            double b = 10;

            // Act
            double result = _calculator.Divide(a, b);

            // Assert
            Assert.AreEqual(2, result);
        }

        // Test for Division by Zero (should throw exception)
        [Test]
        public void Divide_WhenDividingByZero_ThrowsDivideByZeroException()
        {
            // Arrange
            double a = 10;
            double b = 0;

            // Act & Assert
            var ex = Assert.Throws<DivideByZeroException>(() => _calculator.Divide(a, b));
            Assert.AreEqual("Cannot divide by zero.", ex.Message);
        }

        // Test for edge case (adding zero)
        [Test]
        public void Add_WhenAddingZero_ReturnsSameNumber()
        {
            // Arrange
            double a = 5;
            double b = 0;

            // Act
            double result = _calculator.Add(a, b);

            // Assert
            Assert.AreEqual(5, result);
        }

        // Test for edge case (subtracting zero)
        [Test]
        public void Subtract_WhenSubtractingZero_ReturnsSameNumber()
        {
            // Arrange
            double a = 5;
            double b = 0;

            // Act
            double result = _calculator.Subtract(a, b);

            // Assert
            Assert.AreEqual(5, result);
        }
    }
}
