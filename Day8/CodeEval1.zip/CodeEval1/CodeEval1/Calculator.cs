﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorLibrary
{
    public class Calculator
    {
        // Add method for addition
        public double Add(double a, double b)
        {
            return a + b;
        }

        // Subtract method for subtraction
        public double Subtract(double a, double b)
        {
            return a - b;
        }

        // Multiply method for multiplication
        public double Multiply(double a, double b)
        {
            return a * b;
        }

        // Divide method for division, handles division by zero
        public double Divide(double a, double b)
        {
            if (b == 0)
                throw new DivideByZeroException("Cannot divide by zero.");
            return a / b;
        }
    }
}
